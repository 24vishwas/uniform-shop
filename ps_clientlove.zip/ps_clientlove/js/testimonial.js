document.addEventListener('DOMContentLoaded', () => {
    const carousel = document.querySelector('.testimonial-carousel');
    const slides = Array.from(carousel.children);
    const slideCount = slides.length;

    const getCloneMultiplier = () => {
        const screenWidth = window.innerWidth;

        if (screenWidth >= 1200) {
            return 3; // Large screens (desktops)
        } else if (screenWidth >= 768) {
            return 4; // Medium screens (tablets)
        } else {
            return 5; // Small screens (phones)
        }
    };

    // Calculate the width of each slide
    const slideWidth = slides[0].offsetWidth;
    const cloneMultiplier = getCloneMultiplier();
    // Clone slides to create a seamless loop
    for (let i = 0; i < slideCount; i++) {
        const clone = slides[i].cloneNode(true);
        carousel.appendChild(clone);
    }

    // Calculate and set the width of the carousel
    const carouselWidth = slideWidth * (slideCount * cloneMultiplier); // Total width for original + cloned slides
    carousel.style.width = `${carouselWidth}px`;

    // Start the animation
    carousel.style.animation = `slide-animation ${slideCount * 4}s linear infinite`;
    console.log('Slide Width:', slideWidth);
    console.log('Carousel Total Width:', carouselWidth);
});
