<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

use PrestaShop\PrestaShop\Adapter\Presenter\Object\ObjectPresenter;
use PrestaShop\PrestaShop\Core\Addon\Module\ModuleManagerBuilder;
use PrestaShop\PrestaShop\Core\Module\WidgetInterface;

require_once _PS_MODULE_DIR_ . 'ps_clientlove/classes/ClientLove.php';

class Ps_Clientlove extends Module implements WidgetInterface {

    const MODULE_16 = 'blockcmsinfo';

    /**
     * @var string Template used by widget
     */
    private $templateFile;

    public function __construct()
    {
        $this->name = 'ps_clientlove';
        $this->tab = 'front_office_features';
        $this->author = 'PrestaShop';
        $this->version = '1.0.0';
        $this->need_instance = 0;

        $this->bootstrap = true;
        parent::__construct();
        

        $this->displayName = 'Talla Client Love';
        $this->description = 'Talla Client Love';

        $this->ps_versions_compliancy = ['min' => '1.7.5.0', 'max' => _PS_VERSION_];

        $this->templateFile = 'module:ps_clientlove/ps_clientlove.tpl';
    }

    /**
     * @return bool
     */
    public function install()
    {
        return $this->runInstallSteps();
    }

    public function uninstall()
    {
        return parent::uninstall() && $this->uninstallDB(false);
    }

    /**
     * @return bool
     */
    public function runInstallSteps()
    {
        return parent::install()
            && $this->installDB()
            && $this->registerHook('displayHeader')
            && $this->registerHook('displayHome')
            && $this->registerHook('actionShopDataDuplication');
    }



    public function installDB()
    {
        $return = Db::getInstance()->execute('
                CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'client_love` (
                    `id_grid` int(11) NOT NULL AUTO_INCREMENT,
                    `section_title` varchar(255) NOT NULL,
                    `title1` varchar(255) NOT NULL,
                    `description1` text NOT NULL,
                    `url1` varchar(255) NOT NULL,
                    `image1` varchar(255) NOT NULL,
                    `title2` varchar(255) NOT NULL,
                    `description2` text NOT NULL,
                    `url2` varchar(255) NOT NULL,
                    `image2` varchar(255) NOT NULL,
                    `title3` varchar(255) NOT NULL,
                    `description3` text NOT NULL,
                    `url3` varchar(255) NOT NULL,
                    `image3` varchar(255) NOT NULL,
                    `title4` varchar(255) NOT NULL,
                    `description4` text NOT NULL,
                    `url4` varchar(255) NOT NULL,
                    `image4` varchar(255) NOT NULL,
                    `section_button_text` varchar(255) NOT NULL,
                    `section_button_url` varchar(255) NOT NULL,
                    PRIMARY KEY (`id_grid`)
            ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8 ;'
        );

        return $return;
    }

    public function uninstallDB($drop_table = true)
    {
        if (!$drop_table) {
            return true;
        }

        return Db::getInstance()->execute('DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'client_love`');
    }


    public function getContent()
    {
        $output = '';

        if (Tools::isSubmit('saveps_clientlove')) {
            $update = $this->processSaveClientLove();

            if (!$update) {
                $output = '<div class="alert alert-danger conf error">'
                    . $this->trans('An error occurred on saving.', [], 'Admin.Notifications.Error')
                    . '</div>';
            }

            $this->_clearCache($this->templateFile);

            if ($update) {
                Tools::redirectAdmin($this->context->link->getAdminLink('AdminModules') . '&configure=' . $this->name . '&conf=4');
            }
        }

        return $output . $this->renderForm();
    }

    /**
     * @return bool
     */
    public function processSaveClientLove()
    {

        $shops = Tools::getValue('checkBoxShopAsso_configuration', [$this->context->shop->id]);
        $saved = true;
        print_r($_FILES['image1']['tmp_name']);
        foreach ($shops as $shop) {
            Shop::setContext(Shop::CONTEXT_SHOP, $shop);
            $info = new ClientLove(Tools::getValue('id_grid', 1));
            $info->section_title = (string) Tools::getValue('section_title');
            $info->title1 = (string) Tools::getValue('title1');
            $info->description1 = (string) Tools::getValue('description1');
            $info->url1 = (string) Tools::getValue('url1');
            // $info->image1 = (string) Tools::getValue('image1');
            $info->title2 = (string) Tools::getValue('title2');
            $info->description2 = (string) Tools::getValue('description2');
            $info->url2 = (string) Tools::getValue('url2');
            // $info->image2 = (string) Tools::getValue('image2');
            $info->title3 = (string) Tools::getValue('title3');
            $info->description3 = (string) Tools::getValue('description3');
            $info->url3 = (string) Tools::getValue('url3');
            // $info->image3 = (string) Tools::getValue('image3');
            $info->title4 = (string) Tools::getValue('title4');
            $info->description4 = (string) Tools::getValue('description4');
            $info->url4 = (string) Tools::getValue('url4');
            // $info->image4 = (string) Tools::getValue('image4');
            $info->section_button_text = (string) Tools::getValue('section_button_text');
            $info->section_button_url = (string) Tools::getValue('section_button_url');

            $type1 = '';
            $type2 = '';
            $type3 = '';
            $type4 = '';
            $imagesize1 = 0;
            $imagesize2 = 0;
            $imagesize3 = 0;
            $imagesize4 = 0;
            
            if (
                isset($_FILES['image1_1']) &&
                !empty($_FILES['image1_1']['tmp_name'])
            ) {
                $type1 = Tools::strtolower(Tools::substr(strrchr($_FILES['image1_1']['name'], '.'), 1));
                $imagesize1 = @getimagesize($_FILES['image1_1']['tmp_name']);
            }

            if (
                !empty($type1) &&
                !empty($imagesize1) &&
                in_array(
                    Tools::strtolower(Tools::substr(strrchr($imagesize1['mime'], '/'), 1)),
                    [
                        'jpg',
                        'gif',
                        'jpeg',
                        'png',
                    ]
                ) &&
                in_array($type1, ['jpg', 'gif', 'jpeg', 'png'])
            ) {
                $temp_name = tempnam(_PS_TMP_IMG_DIR_, 'PS');
                $salt = sha1(microtime());
                if ($error = ImageManager::validateUpload($_FILES['image1_1'])) {
                    $errors[] = $error;
                } elseif (!$temp_name || !move_uploaded_file($_FILES['image1_1']['tmp_name'], $temp_name)) {
                    return false;
                } elseif (!ImageManager::resize($temp_name, __DIR__ . '/img/' . $salt . '_' . $_FILES['image1_1']['name'], null, null, $type1)) {
                    $errors[] = $this->displayError($this->trans('An error occurred during the image upload process.', [], 'Admin.Notifications.Error'));
                }
                if (file_exists($temp_name)) {
                    @unlink($temp_name);
                }
                $info->image1 = $salt . '_' . $_FILES['image1_1']['name'];
            }


            if (
                isset($_FILES['image2_1']) &&
                !empty($_FILES['image2_1']['tmp_name'])
            ) {
                $type2 = Tools::strtolower(Tools::substr(strrchr($_FILES['image2_1']['name'], '.'), 1));
                $imagesize2 = @getimagesize($_FILES['image2_1']['tmp_name']);
            }

            if (
                !empty($type2) &&
                !empty($imagesize2) &&
                in_array(
                    Tools::strtolower(Tools::substr(strrchr($imagesize2['mime'], '/'), 1)),
                    [
                        'jpg',
                        'gif',
                        'jpeg',
                        'png',
                    ]
                ) &&
                in_array($type2, ['jpg', 'gif', 'jpeg', 'png'])
            ) {
                $temp_name = tempnam(_PS_TMP_IMG_DIR_, 'PS');
                $salt = sha1(microtime());
                if ($error = ImageManager::validateUpload($_FILES['image2_1'])) {
                    $errors[] = $error;
                } elseif (!$temp_name || !move_uploaded_file($_FILES['image2_1']['tmp_name'], $temp_name)) {
                    return false;
                } elseif (!ImageManager::resize($temp_name, __DIR__ . '/img/' . $salt . '_' . $_FILES['image2_1']['name'], null, null, $type2)) {
                    $errors[] = $this->displayError($this->trans('An error occurred during the image upload process.', [], 'Admin.Notifications.Error'));
                }
                if (file_exists($temp_name)) {
                    @unlink($temp_name);
                }
                $info->image2 = $salt . '_' . $_FILES['image2_1']['name'];
            }


            if (
                isset($_FILES['image3_1']) &&
                !empty($_FILES['image3_1']['tmp_name'])
            ) {
                $type3 = Tools::strtolower(Tools::substr(strrchr($_FILES['image3_1']['name'], '.'), 1));
                $imagesize3 = @getimagesize($_FILES['image3_1']['tmp_name']);
            }

            if (
                !empty($type3) &&
                !empty($imagesize3) &&
                in_array(
                    Tools::strtolower(Tools::substr(strrchr($imagesize3['mime'], '/'), 1)),
                    [
                        'jpg',
                        'gif',
                        'jpeg',
                        'png',
                    ]
                ) &&
                in_array($type3, ['jpg', 'gif', 'jpeg', 'png'])
            ) {
                $temp_name = tempnam(_PS_TMP_IMG_DIR_, 'PS');
                $salt = sha1(microtime());
                if ($error = ImageManager::validateUpload($_FILES['image3_1'])) {
                    $errors[] = $error;
                } elseif (!$temp_name || !move_uploaded_file($_FILES['image3_1']['tmp_name'], $temp_name)) {
                    return false;
                } elseif (!ImageManager::resize($temp_name, __DIR__ . '/img/' . $salt . '_' . $_FILES['image3_1']['name'], null, null, $type3)) {
                    $errors[] = $this->displayError($this->trans('An error occurred during the image upload process.', [], 'Admin.Notifications.Error'));
                }
                if (file_exists($temp_name)) {
                    @unlink($temp_name);
                }
                $info->image3 = $salt . '_' . $_FILES['image3_1']['name'];
            }


            if (
                isset($_FILES['image4_1']) &&
                !empty($_FILES['image4_1']['tmp_name'])
            ) {
                $type4 = Tools::strtolower(Tools::substr(strrchr($_FILES['image4_1']['name'], '.'), 1));
                $imagesize4 = @getimagesize($_FILES['image4_1']['tmp_name']);
            }

            if (
                !empty($type4) &&
                !empty($imagesize4) &&
                in_array(
                    Tools::strtolower(Tools::substr(strrchr($imagesize4['mime'], '/'), 1)),
                    [
                        'jpg',
                        'gif',
                        'jpeg',
                        'png',
                    ]
                ) &&
                in_array($type4, ['jpg', 'gif', 'jpeg', 'png'])
            ) {
                $temp_name = tempnam(_PS_TMP_IMG_DIR_, 'PS');
                $salt = sha1(microtime());
                if ($error = ImageManager::validateUpload($_FILES['image4_1'])) {
                    $errors[] = $error;
                } elseif (!$temp_name || !move_uploaded_file($_FILES['image4_1']['tmp_name'], $temp_name)) {
                    return false;
                } elseif (!ImageManager::resize($temp_name, __DIR__ . '/img/' . $salt . '_' . $_FILES['image4_1']['name'], null, null, $type4)) {
                    $errors[] = $this->displayError($this->trans('An error occurred during the image upload process.', [], 'Admin.Notifications.Error'));
                }
                if (file_exists($temp_name)) {
                    @unlink($temp_name);
                }
                $info->image4 = $salt . '_' . $_FILES['image4_1']['name'];
            }

            try {
                $saved = $saved && $info->save();
            } catch (PrestaShopException $e) {
                $saved = false;
            }
        }

        return $saved;
    }

    /**
     * @return string
     */
    protected function renderForm()
    {
        $default_lang = (int) Configuration::get('PS_LANG_DEFAULT');

        $fields_form = [
                'tinymce' => true,
                'legend' => [
                    'title' => 'Talla Client Love',
                ],
                'input' => [
                    [
                        'type' => 'hidden',
                        'name' => 'id_grid',
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->trans('Section Title', [], 'Admin.Global'),
                        'name' => 'section_title',
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->trans('Title #1', [], 'Admin.Global'),
                        'name' => 'title1',
                    ],
                    [
                        'type' => 'textarea',
                        'label' => 'Description #1',
                        'name' => 'description1',
                        'cols' => 40,
                        'rows' => 10,
                        'autoload_rte' => true,
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->trans('Target URL #1', [], 'Modules.Imageslider.Admin'),
                        'name' => 'url1',
                    ],
                    [
                        'type' => 'file_lang',
                        'label' => $this->trans('Image #1', [], 'Admin.Global'),
                        'name' => 'image1',
                        'desc' => $this->trans('Maximum image size: %s.', [ini_get('upload_max_filesize')], 'Admin.Global'),
                        
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->trans('Title #2', [], 'Admin.Global'),
                        'name' => 'title2',
                    ],
                    [
                        'type' => 'textarea',
                        'label' => 'Description #2',
                        'name' => 'description2',
                        'cols' => 40,
                        'rows' => 10,
                        'autoload_rte' => true,
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->trans('Target URL #2', [], 'Modules.Imageslider.Admin'),
                        'name' => 'url2',
                    ],
                    [
                        'type' => 'file_lang',
                        'label' => $this->trans('Image #2', [], 'Admin.Global'),
                        'name' => 'image2',
                        'desc' => $this->trans('Maximum image size: %s.', [ini_get('upload_max_filesize')], 'Admin.Global'),
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->trans('Title #3', [], 'Admin.Global'),
                        'name' => 'title3',
                    ],
                    [
                        'type' => 'textarea',
                        'label' => 'Description #3',
                        'name' => 'description3',
                        'cols' => 40,
                        'rows' => 10,
                        'autoload_rte' => true,
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->trans('Target URL #3', [], 'Modules.Imageslider.Admin'),
                        'name' => 'url3',
                    ],
                    [
                        'type' => 'file_lang',
                        'label' => $this->trans('Image #3', [], 'Admin.Global'),
                        'name' => 'image3',
                        'desc' => $this->trans('Maximum image size: %s.', [ini_get('upload_max_filesize')], 'Admin.Global'),
                        
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->trans('Title #4', [], 'Admin.Global'),
                        'name' => 'title4',
                    ],
                    [
                        'type' => 'textarea',
                        'label' => 'Description #4',
                        'name' => 'description4',
                        'cols' => 40,
                        'rows' => 10,
                        'autoload_rte' => true,
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->trans('Target URL #4', [], 'Modules.Imageslider.Admin'),
                        'name' => 'url4',
                    ],
                    [
                        'type' => 'file_lang',
                        'label' => $this->trans('Image #4', [], 'Admin.Global'),
                        'name' => 'image4',
                        'desc' => $this->trans('Maximum image size: %s.', [ini_get('upload_max_filesize')], 'Admin.Global'),
                        
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->trans('Button Text', [], 'Modules.Imageslider.Admin'),
                        'name' => 'section_button_text',
                    ],
                    [
                        'type' => 'text',
                        'label' => $this->trans('Button Target URL', [], 'Modules.Imageslider.Admin'),
                        'name' => 'section_button_url',
                    ],
                ],
                'submit' => [
                    'title' => $this->trans('Save', [], 'Admin.Actions'),
                ],
        ];

        if (Shop::isFeatureActive() && Tools::getValue('id_grid') == false) {
            $fields_form['input'][] = [
                'type' => 'shop',
                'label' => $this->trans('Shop association', [], 'Admin.Global'),
                'name' => 'checkBoxShopAsso_theme',
            ];
        }

        $lang = new Language((int) Configuration::get('PS_LANG_DEFAULT'));

        $helper = new HelperForm();
        $helper->module = $this;
        $helper->name_controller = 'ps_clientlove';
        $helper->identifier = $this->identifier;
        $helper->token = Tools::getAdminTokenLite('AdminModules');

        $helper->currentIndex = AdminController::$currentIndex . '&configure=' . $this->name;
        $helper->default_form_language = $lang->id;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') ? Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') : 0;
        $helper->toolbar_scroll = true;
        $helper->title = $this->displayName;
        $helper->submit_action = 'saveps_clientlove';
        foreach (Language::getLanguages(false) as $lang) {
            $helper->languages[] = [
                'id_lang' => $lang['id_lang'],
                'iso_code' => $lang['iso_code'],
                'name' => $lang['name'],
                'is_default' => ($default_lang == $lang['id_lang'] ? 1 : 0),
            ];
        }

        $language = new Language((int) Configuration::get('PS_LANG_DEFAULT'));
        $helper->tpl_vars = [
            'uri' => $this->_path,
        ];
        

        $helper->override_folder = '/';
        $helper->fields_value = $this->getFormValues();
        return $helper->generateForm([['form' => $fields_form]]);
    }

    public function getFormValues()
    {
        $fields_value = [];
        $idShop = $this->context->shop->id;

        Shop::setContext(Shop::CONTEXT_SHOP, $idShop);
        $info = new ClientLove(1);

        $fields_value['id_grid'] = $info->id_grid;
        $fields_value['section_title'] = $info->section_title;
        $fields_value['title1'] = $info->title1;
        $fields_value['description1'] = $info->description1;
        $fields_value['url1'] = $info->url1;
        $fields_value['image1'][1] = $info->image1;
        $fields_value['title2'] = $info->title2;
        $fields_value['description2'] = $info->description2;
        $fields_value['url2'] = $info->url2;
        $fields_value['image2'][1] = $info->image2;
        $fields_value['title3'] = $info->title3;
        $fields_value['description3'] = $info->description3;
        $fields_value['url3'] = $info->url3;
        $fields_value['image3'][1] = $info->image3;
        $fields_value['title4'] = $info->title4;
        $fields_value['description4'] = $info->description4;
        $fields_value['url4'] = $info->url4;
        $fields_value['image4'][1] = $info->image4;
        $fields_value['section_button_text'] = $info->section_button_text;
        $fields_value['section_button_url'] = $info->section_button_url;

        return $fields_value;
    }
    public function hookdisplayHeader($params)
    {
        $this->context->controller->registerStylesheet('modules-clientlove', 'modules/' . $this->name . '/css/testimonial.css', ['media' => 'all', 'priority' => 150]);
        $this->context->controller->registerJavascript('modules-clientlove', 'modules/' . $this->name . '/js/testimonial.js', ['position' => 'bottom', 'priority' => 150]);
        
    }

    public function renderWidget($hookName = null, array $configuration = [])
    {
        if (!$this->isCached($this->templateFile, $this->getCacheId('ps_clientlove'))) {
            $widgetVariables = $this->getWidgetVariables($hookName, $configuration);
            if ($widgetVariables === false) {
                return false;
            }

            $this->smarty->assign($widgetVariables);
        }

        return $this->fetch($this->templateFile, $this->getCacheId('ps_clientlove'));
        
    }

    public function getWidgetVariables($hookName = null, array $configuration = [])
    {
        $idShop = (int) $this->context->shop->id;

        $clientLove = new ClientLove(1, $this->context->language->id, $idShop);
        $objectPresenter = new ObjectPresenter();
        $data = $objectPresenter->present($clientLove);
        $data['id_lang'] = $this->context->language->id;
        $data['id_shop'] = $idShop;
        unset($data['id']);

        return ['cms_infos' => $data];
    }
}