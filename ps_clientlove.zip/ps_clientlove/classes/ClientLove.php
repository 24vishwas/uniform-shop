<?php

class ClientLove extends ObjectModel {

    public $id_grid;
    public $title1;
    public $description1;
    public $url1;
    public $image1;
    public $title2;
    public $description2;
    public $url2;
    public $image2;
    public $title3;
    public $description3;
    public $url3;
    public $image3;
    public $title4;
    public $description4;
    public $url4;
    public $image4;
    public $section_title;
    public $section_button_text;
    public $section_button_url;

    public static $definition = [
        'table' => 'client_love',
        'primary' => 'id_grid',
        'fields' => [
            'id_grid' => ['type' => self::TYPE_NOTHING, 'validate' => 'isUnsignedId'],
            'description1' => ['type' => self::TYPE_HTML, 'validate' => 'isCleanHtml', 'size' => 4000],
            'title1' => ['type' => self::TYPE_STRING, 'validate' => 'isCleanHtml', 'size' => 255],
            'url1' => ['type' => self::TYPE_STRING,  'validate' => 'isUrl', 'size' => 255],
            'image1' => ['type' => self::TYPE_STRING,  'validate' => 'isCleanHtml', 'size' => 255],
            'description2' => ['type' => self::TYPE_HTML, 'validate' => 'isCleanHtml', 'size' => 4000],
            'title2' => ['type' => self::TYPE_STRING, 'validate' => 'isCleanHtml', 'size' => 255],
            'url2' => ['type' => self::TYPE_STRING, 'validate' => 'isUrl', 'size' => 255],
            'image2' => ['type' => self::TYPE_STRING, 'validate' => 'isCleanHtml', 'size' => 255],
            'description3' => ['type' => self::TYPE_HTML,'validate' => 'isCleanHtml', 'size' => 4000],
            'title3' => ['type' => self::TYPE_STRING,  'validate' => 'isCleanHtml', 'size' => 255],
            'url3' => ['type' => self::TYPE_STRING,  'validate' => 'isUrl', 'size' => 255],
            'image3' => ['type' => self::TYPE_STRING,'validate' => 'isCleanHtml', 'size' => 255],
            'description4' => ['type' => self::TYPE_HTML,'validate' => 'isCleanHtml', 'size' => 4000],
            'title4' => ['type' => self::TYPE_STRING, 'validate' => 'isCleanHtml', 'size' => 255],
            'url4' => ['type' => self::TYPE_STRING,'validate' => 'isUrl', 'size' => 255],
            'image4' => ['type' => self::TYPE_STRING, 'validate' => 'isCleanHtml', 'size' => 255],
            'section_title' => ['type' => self::TYPE_STRING, 'validate' => 'isCleanHtml', 'size' => 255],
            'section_button_text' => ['type' => self::TYPE_STRING,'validate' => 'isCleanHtml', 'size' => 255],
            'section_button_url' => ['type' => self::TYPE_STRING, 'validate' => 'isCleanHtml', 'size' => 255],
        ],
    ];

}